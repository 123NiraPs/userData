export const GET_ALL_DATA = "GET_ALL_DATA";
export const GET_ADD_DATA = "GET_ADD_DATA";
