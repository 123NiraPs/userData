import AddUser from "./AddUser";
import "./App.css";
import UserData from "./UserData";

function App() {
  return (
    <div className="App">
      <AddUser />
      <UserData />
    </div>
  );
}

export default App;
